package com.example.my31_navigationdrawer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;


public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    Toolbar toolbar;
    Fragment1 fragment1;
    Fragment2 fragment2;
    Fragment3 fragment3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawerLayout = findViewById(R.id.drawerLayout);
        //string.xml에 사용할 스트링을 미리 작성해두고 그 주소(int 타입)을 가져다 사용한다.
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();



        //프래그먼트
        fragment1 = new Fragment1();
        fragment2 = new Fragment2();
        fragment3 = new Fragment3();

        getSupportFragmentManager().beginTransaction().replace(R.id.container, fragment1).commit();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        /*
        //방법 1. setNavigationItemSelectedListener(new O) ▶ 자동 완성
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                return false;
            }
        });
         */

        /*----------------------헤드 드로어에 로그인 정보 표시하기-------------------------*/
        String loginID = "ASDF";
        //헤더의 0번지 뷰에 접근한다
        View headerView = navigationView.getHeaderView(0);
        //헤더뷰에 id로 접근하면 에러가 나온다.
        //View headerView = navigationView.findViewById(R.id.headerLayout);

        //헤더 뷰의 객체 초기화
        ImageView loginImage = headerView.findViewById(R.id.loginImage);
        TextView navLoginID = headerView.findViewById(R.id.loginID);

        //ID와 이미지를 로그인된 ID와 이미지로 바꾸기
        navLoginID.setText("반갑습니다 " + loginID + "님");
        loginImage.setImageResource(R.drawable.dream01);

        //로그인 ID가 있으면 커뮤니케이트 메뉴가 보이게 설정
        if(loginID != null) {
            navigationView.getMenu().findItem(R.id.communicate).setVisible(true);
        }

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_SHORT).setAction("Action", null).show();
            }
        });
    }

    //방법 2. 메인액티비티 implements NavigationView.OnNavigationItemSelectedListener ▶ implements methods
    //navigationView 객체를 초기화하고 navigationView.setNavigationItemSelectedListener(this);
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        int selectedItemId = menuItem.getItemId();

        if (selectedItemId == R.id.nav_home) {
            Toast.makeText(this, "첫 번째 메뉴 선택", Toast.LENGTH_SHORT).show();
            onFragmentSelected(0, null);
        } else if (selectedItemId == R.id.nav_gallery) {
            Toast.makeText(this, "두 번째 메뉴 선택", Toast.LENGTH_SHORT).show();
            onFragmentSelected(1, null);
        } else if (selectedItemId == R.id.nav_slideshow) {
            Toast.makeText(this, "세 번째 메뉴 선택", Toast.LENGTH_SHORT).show();
            onFragmentSelected(2, null);
        } else if (selectedItemId == R.id.nav_tools) {
            Toast.makeText(this, "네 번째 메뉴 선택", Toast.LENGTH_SHORT).show();
            onFragmentSelected(3, null);
        } else if (selectedItemId == R.id.nav_share) {
            Toast.makeText(this, "다섯 번째 메뉴 선택", Toast.LENGTH_SHORT).show();
            onFragmentSelected(4, null);
        } else if (selectedItemId == R.id.nav_send) {
            Toast.makeText(this, "여섯 번째 메뉴 선택", Toast.LENGTH_SHORT).show();
            onFragmentSelected(5, null);
        }

        //드로어 닫기
        DrawerLayout drawerLayout = findViewById(R.id.drawerLayout);
        drawerLayout.closeDrawer(GravityCompat.START);

        return true;
    } //onNavigationItemSelected()

    public void onFragmentSelected(int position, Bundle bundle) {
        Fragment curFragment = null;

        if (position == 0) {
            curFragment = fragment1;
            toolbar.setTitle("첫 번째 화면");
        } else if (position == 1) {
            curFragment = fragment2;
            toolbar.setTitle("두 번째 화면");
        } else if (position == 2) {
            curFragment = fragment3;
            toolbar.setTitle("세 번째 화면");
        } else if (position == 3) {
            curFragment = fragment1;
            toolbar.setTitle("네 번째 화면");
        } else if (position == 4) {
            curFragment = fragment2;
            toolbar.setTitle("다섯 번째 화면");
        } else if (position == 5) {
            curFragment = fragment3;
            toolbar.setTitle("여섯 번째 화면");
        }
        getSupportFragmentManager().beginTransaction().replace(R.id.container, curFragment).commit();
    } //onFragmentSelect()

    //뒤로가기 버튼이 눌렸을때 작동하는 메서드
    @Override
    public void onBackPressed() {
        DrawerLayout drawerLayout = findViewById(R.id.drawerLayout);
        if(drawerLayout.isDrawerOpen(GravityCompat.START)) { // 드로어가 열려있다면
            drawerLayout.closeDrawer(GravityCompat.START);   // 드로어를 닫는다.
        } else {
            super.onBackPressed();
        }
    } //onBackPressed()
}
