package com.example.my07_alllayout;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    //변수 선언
    Button btnChange01, btnChange02;
    ImageView frameImage01, frameImage02, scrollImage01;
    int selIdx = 1;
    int selIdx2 = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //변수 id 찾기
        btnChange01 = findViewById(R.id.btnChange01);
        btnChange02 = findViewById(R.id.btnChange02);
        frameImage01 = findViewById(R.id.frameImage01);
        frameImage02 = findViewById(R.id.frameImage02);
        scrollImage01 = findViewById(R.id.scrollImage01);

        //버튼에 기능 넣기
        btnChange01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(selIdx == 1) {
                    frameImage01.setVisibility(View.GONE);
                    frameImage02.setVisibility(View.VISIBLE);
                    selIdx = 2;
                } else if (selIdx == 2) {
                    frameImage01.setVisibility(View.VISIBLE);
                    frameImage02.setVisibility(View.GONE);
                    selIdx = 1;
                } // if else if
            } // onClick
        }); // btnChange01 setOnClickListener

        btnChange02.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(selIdx2 == 1) {
                    scrollImage01.setImageResource(R.drawable.image02);
                    selIdx2 = 2;
                } else if (selIdx2 == 2) {
                    scrollImage01.setImageResource(R.drawable.image01);
                    selIdx2 = 1;
                } // if else if
            } // onClick
        }); // setOnClickListener
    } // onCreate
} // MainActivity