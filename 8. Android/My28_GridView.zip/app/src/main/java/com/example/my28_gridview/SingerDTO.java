package com.example.my28_gridview;

public class SingerDTO {
    String name;
    String phoneNum;
    int age;
    int resId;

    public SingerDTO() {}

    public SingerDTO(String name, String phoneNum, int age, int resId) {
        this.name = name;
        this.phoneNum = phoneNum;
        this.age = age;
        this.resId = resId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getResId() {
        return resId;
    }

    public void setResId(int resId) {
        this.resId = resId;
    }
}
