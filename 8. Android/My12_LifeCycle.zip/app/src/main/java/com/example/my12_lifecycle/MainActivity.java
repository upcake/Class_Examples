package com.example.my12_lifecycle;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "onCreate : 호출됨");

        //버튼을 누르면 서브1액티비티가 나오게끔 설정
        Button btnMain = findViewById(R.id.btnMain);
        btnMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Sub1Activity.class);
                startActivity(intent);
            }
        });
    }

    //우클릭 - Generate... - Override Methods...
    //실행 하면 onCreate - onStart - onResume
    //메인 버튼 누르면 onPause - onStop
    //서브 버튼 누르면 onRestart - onStart - onResume
    //뒤로가기 누르면 onPuase - onStop - onDestroy
    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart : 호출됨");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume : 호출됨");
        loadPersonal();
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop : 호출됨");
        savePersonal();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy : 호출됨");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause : 호출됨");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "onRestart : 호출됨");
    }

    //데이터 저장하기 : onStop
    public void savePersonal() {
        SharedPreferences pref = getSharedPreferences("personal", Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("id", "hong_gil_dong");
        editor.putInt("pw", 1234);
        editor.commit();
    }
    //저장된 데이터 불러오기 : onResume
    public void loadPersonal() {
        SharedPreferences pref = getSharedPreferences("personal", Activity.MODE_PRIVATE);
        if (pref != null) {
            String id = pref.getString("id", "CSS");
            int pw = pref.getInt("pw", 0);

            Log.d(TAG, "loadPersonal: " + id + ", " + pw);
        }
    }
}