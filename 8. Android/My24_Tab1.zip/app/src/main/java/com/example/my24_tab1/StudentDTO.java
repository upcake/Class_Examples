package com.example.my24_tab1;

import java.io.Serializable;

//직렬화 잊지 말 것
public class StudentDTO implements Serializable {
    String name;
    int age;

    public StudentDTO() {}

    public StudentDTO(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
