package com.example.my19_animation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    //객체 선언
    TextView textView;
    Button button;
    Animation flowAnim;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //객체 초기화
        textView = findViewById(R.id.textView);
        button = findViewById(R.id.button);

        //Animation 설정
        flowAnim = AnimationUtils.loadAnimation(this, R.anim.flow);
        //Context 설정할때
        //onCreate 내부에서는 this가 가능하고
        //외부에서는 ~~.this나 getApplicationContext()를 사용한다.

        //버튼 기능추가
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textView.startAnimation(flowAnim);
            }
        });
    }
}
