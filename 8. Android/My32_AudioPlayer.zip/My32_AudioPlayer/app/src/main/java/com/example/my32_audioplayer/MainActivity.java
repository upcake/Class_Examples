package com.example.my32_audioplayer;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    //외부 URL에서 가져올 경우
//    String AUDIO_URL = "http://sites.google.com/site/ubiaccessmobile/sample_audio.amr";
    MediaPlayer mediaPlayer;
    int position = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //버튼 객체 초기화
        Button btnStart = findViewById(R.id.button1);
        Button btnStop = findViewById(R.id.button2);
        Button btnPause = findViewById(R.id.button3);
        Button btnResume = findViewById(R.id.button4);

        //시작 버튼 기능 추가
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                playAudio(AUDIO_URL);
                playAudioInnerProject(R.raw.m01);
                Toast.makeText(MainActivity.this, "재생 시작!", Toast.LENGTH_SHORT).show();
            }
        });

        //정지 버튼 기능 추가
        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mediaPlayer != null) { // mediaPlayer가 재생중일 때
                    mediaPlayer.stop();
                    Toast.makeText(MainActivity.this, "음악 정지!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //일시정지 버튼 기능 추가
        btnPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mediaPlayer != null) {
                    position = mediaPlayer.getCurrentPosition();
                    mediaPlayer.pause();
                    Toast.makeText(MainActivity.this, "음악 일시정지! : " + position, Toast.LENGTH_SHORT).show();
                }
            }
        });

        //재시작 버튼 기능 추가
        btnResume.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mediaPlayer != null && !mediaPlayer.isPlaying()) { // 미디어 플레이어에 재생 흔적이 있으면서 재생중이 아닐때
                    mediaPlayer.start();
                    mediaPlayer.seekTo(position);
                    Toast.makeText(MainActivity.this, "음악 재시작! : " + position, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    private void playAudio(String audio_url) {
        killMediaPlayer();
        try {
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(audio_url);
            mediaPlayer.prepare();
            mediaPlayer.start();
        } catch (Exception e) {
            e.printStackTrace();
            e.getMessage(); //에러 발생시 메세지 출력
        }
    } //playAudio()

    private void playAudioInnerProject(int resId) {
        killMediaPlayer();
        try {
            mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.m01);
            mediaPlayer.start();
        } catch (Exception e) {
            e.printStackTrace();
            e.getMessage(); //에러 발생시 메세지 출력
        }
    } //playAudio()

    //기존의 재생되고 있는 미디어플레이어를 제거하는 메서드
    private void killMediaPlayer() {
        if(mediaPlayer != null) {
            mediaPlayer.release();
        }
    } //killMediaPlayer()

    //어플리케이션이 정지될 경우 작동하는 메서드
    @Override
    protected void onStop() {
        super.onStop();
        killMediaPlayer();
    } //onStop()
}
