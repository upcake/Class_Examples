package com.example.my11_dialog;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    //변수 선언
    Button btnOpen;
    TextView tvAlarm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //변수 초기화
        tvAlarm = findViewById(R.id.tvAlarm);
        btnOpen = findViewById(R.id.btnOpen);

        //버튼에 기능 추가
        btnOpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMessage();
            }
        });
    }

    //메서드는 onCreate 밖에 만든다.
    private void showMessage() {
        //AldertDialog.Builder(컨텍스트)
        //컨텍스트 : this, getApplicationContext() 등
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("안내");
        builder.setMessage("종료하시겠습니까?");
        builder.setIcon(android.R.drawable.ic_dialog_alert);

        //DialogInterface의 OnClickListener를 사용한다.
        builder.setPositiveButton("예", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String message = "'예' 버튼이 눌렸습니다. : " + which;    //which : -1
                tvAlarm.setText(message);
            }
        });

        builder.setNegativeButton("아니오", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String message = "'아니오' 버튼이 눌렸습니다. : " + which; //which : -2
                tvAlarm.setText(message);
            }
        });

        builder.setNeutralButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String message = "'취소' 버튼이 눌렸습니다. : " + which; //which : -3
                tvAlarm.setText(message);
            }
        });

        //dialog 창을 띄운다.
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
