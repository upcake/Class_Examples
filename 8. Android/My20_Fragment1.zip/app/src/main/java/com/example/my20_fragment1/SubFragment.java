package com.example.my20_fragment1;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class SubFragment extends Fragment {
    //1. Fragment를 상속한다. (extends Fragment)
    //2. XML과 연결한다. (onCreateView, ViewGroup rootView = inflater.inflate())
    //3. 반환 값을 설정한다. (rootView)
    //4. 현재 액티비티 설정 (activity)
    //5. 기능 설정

    //메인 액티비티 객체 선언
    MainActivity activity;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_sub, container, false);

        activity = (MainActivity) getActivity();

        //버튼2 객체 초기화
        Button button2 = rootView.findViewById(R.id.button2);

        //버튼2 기능 추가
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.onFragmentChange(2);
            }
        });

        return rootView;
    }
}
