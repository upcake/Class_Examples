package com.example.my20_fragment1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.FrameLayout;

public class MainActivity extends AppCompatActivity {
    //객체 선언
    MainFragment mainFragment;
    SubFragment subFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //FragmentManager : ragment를 다루는 작업을 해주는 객체
        //getSupportFragmentManager와 getFragmentManager가 있는데 Support 붙은 것이 구버전 API까지 지원한다.
        mainFragment = (MainFragment) getSupportFragmentManager().findFragmentById(R.id.mainFragment);

        //subFragment 객체 초기화
        subFragment = new SubFragment();
    }

    //프래그먼트가 바뀔때 작동하게끔 작성한 메서드
    public void onFragmentChange(int fragmentNum) {
        //프래그먼트의 번호에 따라 다르게 작동하는 조건문
        if(fragmentNum == 1) {
            getSupportFragmentManager().beginTransaction().replace(R.id.action_container, subFragment).commit();
        } else if(fragmentNum == 2) {
            getSupportFragmentManager().beginTransaction().replace(R.id.action_container, mainFragment).commit();
        }
    }
}