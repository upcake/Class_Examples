package com.example.my20_fragment1;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class MainFragment extends Fragment {
    //1. Fragment를 상속한다. (extends Fragment)
    //2. XML과 연결한다. (onCreateView, ViewGroup rootView = inflater.inflate())
    //3. 반환 값을 설정한다. (rootView)

    //메인 액티비티 객체 선언
    MainActivity activity;

    //화면이 붙을때 작동하는 메서드
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        //현재 소속된 액티비티를 메인 액티비티로 한다.
        activity = (MainActivity) getActivity();
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //fragment_xml를 MainFragment.java와 묶어주는 역할을 하는 메서드
        //inflate 시키면 Object 타입으로 넘어오기 때문에 캐스팅 필요
        //(사용할 자원, 자원을 담을 곳, T/F)
        //메인에 직접 들어가면 True, 프래그먼트에 있으면 False
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_main, container, false);

        //fragment_main.xml에 접근하기위해서는 rootView. 으로 접근해야한다
        //버튼1 초기화
        Button button1 = rootView.findViewById(R.id.button1);

        //버튼1 기능 추가
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.onFragmentChange(1);
            }
        });

        //ViewGroup은 View에 속하므로 View가 리턴 타입이어도 ViewGroup을 리턴할 수 있다.
        return rootView;
    }
}
