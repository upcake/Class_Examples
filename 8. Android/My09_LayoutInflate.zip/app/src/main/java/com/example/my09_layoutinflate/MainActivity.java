package com.example.my09_layoutinflate;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //변수 선언
    Button btnMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //변수 찾기
        btnMain = findViewById(R.id.btnMain);


        //기능 추가
        btnMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LinearLayout linear = findViewById(R.id.linear);
                RelativeLayout relative = findViewById(R.id.relative);

                //인플레이트
                //Object 타입을 캐스팅하라는 에러가 나오는데 Alt + Enter로 쉽게 에러를 고칠 수 있다.
                LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                inflater.inflate(R.layout.sub1_layout, linear, true);
                inflater.inflate(R.layout.sub2_layout, relative, true);

                //서브 버튼 초기화화
               Button btnSub1 = linear.findViewById(R.id.button1);
               Button btnSub2 = relative.findViewById(R.id.button2);

               //서브 버튼 기능 추가
                btnSub1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(MainActivity.this, "리니어 버튼 클릭", Toast.LENGTH_SHORT).show();
                    }
                });

                btnSub2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(MainActivity.this, "렐러티브 버튼 클릭", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
}
