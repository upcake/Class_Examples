package com.example.my21_fragment2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    //프래그먼트 객체 선언
    ListFragment listFragment;
    ViewerFragment viewerFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //프래그먼트매니저, 프래그먼트 객체 초기화
        FragmentManager manager = getSupportFragmentManager();
        listFragment = (ListFragment) manager.findFragmentById(R.id.listFragment);
        viewerFragment = (ViewerFragment) manager.findFragmentById(R.id.viewerFragment);
    }

    //리스트 프래그먼트의 이미지 버튼이 눌렸을 때,
    //① 그 버튼의 번호를 뷰어프래그먼트에 전달하는 기능
    /*
    public void onImageChange(int btnNum) {
        viewerFragment.setImageChange(btnNum);
    }
    */
    // ② 이미지 번호를 뷰어프래그먼트에 전달하는 기능
    public void onImageChange(int resId) {
        viewerFragment.setImageChange(resId);
    }
}
