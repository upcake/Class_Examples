package com.example.my21_fragment2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ViewerFragment extends Fragment {
    //객체 선언
    MainActivity activity;
    ImageView imageView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //XML과 연결
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_viewer, container, false);

        //메인 액티비티 객체 초기화
        activity = (MainActivity) getActivity();

        //이미지뷰 객체 초기화
        imageView = rootView.findViewById(R.id.imageView);

        return rootView;
    }

    //전달 받은 버튼의 번호에 따라 이미지를 바꾸는 메서드
    public void setImageChange(int btnNum) {
        if(btnNum == 1) {
            imageView.setImageResource(R.drawable.image01);
        } else if(btnNum == 2) {
            imageView.setImageResource(R.drawable.image02);
        } else if(btnNum == 3) {
            imageView.setImageResource(R.drawable.image03);
        }
    }
}
