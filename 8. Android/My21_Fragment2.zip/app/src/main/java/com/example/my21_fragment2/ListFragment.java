package com.example.my21_fragment2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ListFragment extends Fragment {
    //메인 액티비티 객체 선언
    MainActivity activity;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //XML과 연결
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_list, container, false);

        //액티비티 객체 초기화
        activity = (MainActivity) getActivity();

        //버튼 객체 초기화
        Button button1 = rootView.findViewById(R.id.button1);
        Button button2 = rootView.findViewById(R.id.button2);
        Button button3 = rootView.findViewById(R.id.button3);

        /* 이미지 변경 방법 ① : 번호를 보내서 변경
        //버튼1 기능 추가 : 메인 액티비티의 onImageChange 메서드에 1 전달
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.onImageChange(1);
            }
        });

        //버튼2 기능 추가 : 메인 액티비티의 onImageChange 메서드에 2 전달
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.onImageChange(2);
            }
        });

        //버튼3 기능 추가 : 메인 액티비티의 onImageChange 메서드에 3 전달
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.onImageChange(3);
            }
        }); */

        //이미지 변경 방법 ② : 번호를 보내서 변경
        //버튼1 기능 추가 : 메인 액티비티의 onImageChange 메서드에 1 전달
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.onImageChange(R.drawable.image01);
            }
        });


        //버튼2 기능 추가 : 메인 액티비티의 onImageChange 메서드에 2 전달
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.onImageChange(R.drawable.image02);
            }
        });

        //버튼3 기능 추가 : 메인 액티비티의 onImageChange 메서드에 3 전달
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.onImageChange(R.drawable.image03);
            }
        });
        return rootView;
    }
}