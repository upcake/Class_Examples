package com.example.my33_audiorecorder;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.pedro.library.AutoPermissions;
import com.pedro.library.AutoPermissionsListener;

import java.io.File;
import java.io.IOException;

public class MainActivity extends AppCompatActivity implements AutoPermissionsListener {
    //객체 선언
    String fileName;
    MediaPlayer player;
    MediaRecorder recorder;

    //로그캣 사용 준비
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //자동으로 권한 주어지게 설정
        AutoPermissions.Companion.loadAllPermissions(this, 101);

        //sdCard에 외부 저장장치의 절대 경로를 초기화
        String sdCard = Environment.getExternalStorageDirectory().getAbsolutePath();

        //File.separator : 경로에 쓰이는 슬래쉬(/)와 같다.
        //fileName =  sdCard + "/" + "recorded.mp4";
        fileName = sdCard + File.separator + "recorded.mp4";
        Log.d(TAG, "onCreate: " + fileName);

        //버튼 객체 초기화
        Button btnRecord = findViewById(R.id.button1);
        Button btnRecStop = findViewById(R.id.button2);
        Button btnPlay = findViewById(R.id.button3);
        Button btnStop= findViewById(R.id.button4);

        //녹음 버튼 기능 추가
        btnRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(recorder != null) { //레코더에 작동 흔적이 있다면 레코더 흔적을 없앤다.
                    recorder.stop();
                    recorder.release(); //release() : 메모리에서 내림
                    recorder = null;
                }
                recorder = new MediaRecorder();
                recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                recorder.setAudioEncoder(MediaRecorder.AudioEncoder.DEFAULT);

                recorder.setOutputFile(fileName);

                try {
                    Toast.makeText(MainActivity.this, "녹음을 시작합니다", Toast.LENGTH_SHORT).show();
                    recorder.prepare();
                    recorder.start();
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.d(TAG, "!!!btnRecord onClick Exception!!!");
                }
            }
        });

        //녹음 정지 버튼 기능 추가
        btnRecStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(recorder == null) {  //레코더가 작동중이지 않으면
                    return;
                }
                recorder.stop();
                recorder.release();
                recorder = null;
            }
        });

        //재생 버튼 기능 추가
        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(player != null) { //재생중이면
                    player.stop();
                    player.release();
                    player = null;
                }

                try {
                    player = new MediaPlayer();
                    player.setDataSource(fileName);
                    player.prepare();
                    player.start();
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.d(TAG, "!!!btnPlay onClick Exception!!!");
                }
            }
        });

        //재생 정지 버튼 기능 추가
        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                player.stop();
                player.release();
                player = null;
            }
        });
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        AutoPermissions.Companion.parsePermissions(this, requestCode, permissions, this);
    }

    @Override
    public void onDenied(int i, String[] strings) {
        Toast.makeText(this, "Permissions Denied", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onGranted(int i, String[] strings) {
        Toast.makeText(this, "Permissions Granted", Toast.LENGTH_SHORT).show();
    }
}
