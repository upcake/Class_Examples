package com.example.my22_viewpager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    //객체 선언
    Button button1;
    ViewPager pager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //객체 초기화
        button1 = findViewById(R.id.button1);
        pager = findViewById(R.id.pager);

        //페이저 기능 추가
        //setOffscreenPageLimit() : 좌우를 포함해해 미리 생성해 둘 페이지 수
       pager.setOffscreenPageLimit(3);

       //페이저 어댑터 객체 초기화
        //MyPagerAdapter는 프래그먼트매니저를 매개 변수로 받는다.
       MyPagerAdapter adapter = new MyPagerAdapter(getSupportFragmentManager());

       //프래그먼트 객체 초기화
       Fragment1 fragment1 = new Fragment1();
       Fragment2 fragment2 = new Fragment2();
       Fragment3 fragment3 = new Fragment3();

       //어댑터에 프래그먼트 추가
       adapter.addItem(fragment1);
       adapter.addItem(fragment2);
       adapter.addItem(fragment3);

       //페이저에 어댑터를 붙여준다.
       pager.setAdapter(adapter);

       //버튼 초기화, 기능 추가
       Button button1 = findViewById(R.id.button1);
       button1.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               //페이저에서 이동할 좌표를 지정하는 메서드
               pager.setCurrentItem(1);
           }
       });
    }

    class MyPagerAdapter extends FragmentStatePagerAdapter {
        //MyPagerAdapter 클래스를 만들고 Alt + Enter로 implement 하고 생성자를 만든다
        public MyPagerAdapter(@NonNull FragmentManager fm) {
            super(fm);
        }

        //Fragment를 넣을 리스트 초기화
        ArrayList<Fragment> items = new ArrayList<>();

        //리스트에 프래그먼트를 추가하는 메서드를 만든다
        public void addItem(Fragment item) {
            items.add(item);
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            //items의 프래그먼트 인덱스를 받아서 리턴하게끔 설정
            return items.get(position);
        }

        //items에 들어있는 원소의 갯수를 반환
        @Override
        public int getCount() {
            return items.size();
        }

        //CharSequence : 어떤 글자를 넘길 것인가
        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            return "페이지" + (position + 1);
        }
    }
}