package com.example.my42_asynctask;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.ProgressBar;

public class BackgroundTask extends AsyncTask<Void, Integer, String> {
    //Void → doInBackground
    //Integer → onProgressUpdate
    //String → onPostExcute

    /*
    ① 생성자 만들기
    ② onPreExecute() : 넘겨받은 객체들에 초기화가 필요할때 사용
    ③ doInBackGround  : 대부분의 기능들은 여기다 작성
    ④ onProgressUpdate : 필요하면 씀, 안쓰면 매개 변수의 Integer를 Void로 바꿔준다
    ⑤ onPostExecute() : String도 필요하면 쓰고 안쓰면 String을 Void로 바꿔준다

     */
    private static final String TAG = "BackgroundTask";
    
    ProgressBar progressBar;
    int value;

    public BackgroundTask(ProgressBar progressBar, int value) {
        this.progressBar = progressBar;
        this.value = value;
    }

    //onPreExecute → doInBackground → onProgressUpdate(값이 필요하다면 작동) → onPostExecute
    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        value = 0;
        progressBar.setProgress(value);
    }

    //doInBackground에서 리턴한 값은 onPostExecute로 간다. (리턴 타입과 onPostExecute의 매개변수의 타입이 같아야함)
    @Override
    protected String doInBackground(Void ... voids) {
        while (isCancelled() == false) {
            value++;
            if(value >= 100) {
                break;
            } else {
                publishProgress(value);
                //publishProgress(value, value + 1, value + 2);
            }

            try {
                Thread.sleep(20);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return "100% 완료!";
    }

    @Override
    protected void onProgressUpdate(Integer ... values) {
        super.onProgressUpdate(values);

        progressBar.setProgress(values[0].intValue());
        //Log.d(TAG, "onProgressUpdate: " + values[1].toString());
        //Log.d(TAG, "onProgressUpdate: " + values[2].toString());
    }

    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);

        Log.d(TAG, "onPostExecute: " + result);

        progressBar.setProgress(0);
    }

    @Override
    protected void onCancelled() {
        super.onCancelled();
        Log.d(TAG, "onCancelled: 실행 취소됨!");

        progressBar.setProgress(0);
    }
}
