package com.example.my42_asynctask;
//Async : asynchronous 동시에 존재하지 않는, 비동기식의

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

public class MainActivity extends AppCompatActivity {
    //객체 선언
    BackgroundTask backgroundTask;
    int value;

    ProgressBar progressBar;
    Button button1, button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //객체 초기화
        progressBar = findViewById(R.id.progressBar);
        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);

        //실행 버튼
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                backgroundTask = new BackgroundTask(progressBar, value); //backgroundTask 객체 초기화
                backgroundTask.execute(); // backgroundTask 실행
            }
        });

        //취소 버튼
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                backgroundTask.cancel(true);
            }
        });
    }
}
