package com.example.my41_notice;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    NotificationManager manager;

    private static String CHANNEL_ID1 = "channel1";
    private static String CHANNEL_NAME1 = "channel1";

    private static String CHANNEL_ID2 = "channel2";
    private static String CHANNEL_NAME2 = "channel2";

    private static String CHANNEL_ID3 = "channel3";
    private static String CHANNEL_NAME3 = "channel3";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //알림 띄우기 버튼
        Button button1 = findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showNoti1();
            }
        });

        //알림 띄우고 클릭하기 버튼
        Button button2 = findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showNoti2();
            }
        });

        //많은 글자 알림 띄우기 버튼
        Button button3 = findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showNoti3();
            }
        });
    }

    private void showNoti1() {
        manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationCompat.Builder builder = null;
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if(manager.getNotificationChannel(CHANNEL_ID1) == null) {
                manager.createNotificationChannel(new NotificationChannel(CHANNEL_ID1, CHANNEL_NAME1, NotificationManager.IMPORTANCE_DEFAULT));
                builder = new NotificationCompat.Builder(this, CHANNEL_ID1);
            } else if(manager.getNotificationChannel(CHANNEL_ID1) != null) {
                builder = new NotificationCompat.Builder(this, CHANNEL_ID1);
            }
        } else {
            builder = new NotificationCompat.Builder(this);
        }

        builder.setContentTitle("간단 알림");           //알림 제목 설정
        builder.setContentText("알림 메시지입니다.");   //알림 내용 설정
        builder.setSmallIcon(android.R.drawable.ic_menu_view);
        Notification noti = builder.build();

        manager.notify(1, noti);
    } //showNoti1()

    private void showNoti2() {
        manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationCompat.Builder builder = null;
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if(manager.getNotificationChannel(CHANNEL_ID2) == null) {
                manager.createNotificationChannel(new NotificationChannel(CHANNEL_ID2, CHANNEL_NAME2, NotificationManager.IMPORTANCE_DEFAULT));
                builder = new NotificationCompat.Builder(this, CHANNEL_ID2);
            } else if(manager.getNotificationChannel(CHANNEL_ID2) != null) {
                builder = new NotificationCompat.Builder(this, CHANNEL_ID2);
            }
        } else {
            builder = new NotificationCompat.Builder(this);
        }

        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 1004, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        //PendingIntent 미래 어느 특정 이벤트 발생 시점에 Intent를 발생시키기위해 사용하는 Intent
        //메인 화면이 하나 더 나오기 때문에 뒤로가기를 누르면 새로 열린 메인 화면이 닫히게 된다.
        builder.setContentTitle("간단 알림 클릭");
        builder.setContentText("클릭 알림 메시지입니다.");
        builder.setSmallIcon(android.R.drawable.ic_menu_view);
        builder.setAutoCancel(true); //클릭하면 사라지게끔 설정
        builder.setContentIntent(pendingIntent);

        Notification noti = builder.build();
        manager.notify(2, noti);
    } //showNoti2()

    private void showNoti3() {
        manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationCompat.Builder builder = null;
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if(manager.getNotificationChannel(CHANNEL_ID3) == null) {
                manager.createNotificationChannel(new NotificationChannel(CHANNEL_ID3, CHANNEL_NAME3, NotificationManager.IMPORTANCE_DEFAULT));
                builder = new NotificationCompat.Builder(this, CHANNEL_ID3);
            } else if(manager.getNotificationChannel(CHANNEL_ID3) != null) {
                builder = new NotificationCompat.Builder(this, CHANNEL_ID3);
            }
        } else {
            builder = new NotificationCompat.Builder(this);
        }

        NotificationCompat.BigTextStyle style = new NotificationCompat.BigTextStyle();
        style.bigText("많은 글자들입니다 많은 글자들입니다 많은 글자들입니다\n"
                + "많은 글자들입니다 많은 글자들입니다 많은 글자들입니다\n"
                + "많은 글자들입니다 많은 글자들입니다 많은 글자들입니다\n"
                + "많은 글자들입니다 많은 글자들입니다 많은 글자들입니다\n"
                + "많은 글자들입니다 많은 글자들입니다 많은 글자들입니다");
        style.setBigContentTitle("많은 글자 제목입니다");
        style.setSummaryText("요약글입니다.");

        builder = new NotificationCompat.Builder(this, CHANNEL_ID3)
                //.setContentTitle("알림 제목") // 이런식으로 연달아서 쓸 수도 있다.
                .setSmallIcon(android.R.drawable.ic_menu_send)
                .setStyle(style);

        Notification noti = builder.build();
        manager.notify(3, noti);
    } //showNoti3()
}
