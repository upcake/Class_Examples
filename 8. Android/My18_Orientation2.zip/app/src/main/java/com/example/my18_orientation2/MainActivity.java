package com.example.my18_orientation2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Configuration;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //객체 선언
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //객체 초기화
        textView = findViewById(R.id.textView);
    }

    //manifest에서 설정한 config중에 무언가가 바뀌면 작동하는 메서드
    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        //방향이 가로 방항으로 바뀌었으면 토스트를 띄우고 가로 방향으로 메세지를 바꿈
        if(newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            showToast("방향 : Landscape");
            textView.setText("가로 방향(Landscape)");
        //또는 방향이 세로 방향으로 바뀌었으면 토스트를 띄움
        } else if(newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            showToast("방향 : Portrait");
            textView.setText("세로 방향(Portrait)");
        }
    }

    //넘겨 받은 문자열을 Toast로 보여주는 메서드
    private void showToast(String str) {
        Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
    }
}
