package com.example.my16_progress;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //객체 선언
    ProgressBar progressBar;
    EditText editText;
    Button button1, button2, button3;
    ProgressDialog dialog;
    SeekBar seekBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //객체 초기화
        progressBar = findViewById(R.id.progressBar);
        editText = findViewById(R.id.editText);
        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        seekBar = findViewById(R.id.seekBar);

        //progressBar 설정
        progressBar = findViewById(R.id.progressBar);
        progressBar.setIndeterminate(false);
        progressBar.setMax(100);
        progressBar.setProgress(20);

        //버튼에 기능 추가
        //버튼 1: 진행도 바
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            if(editText.getText().toString().length() != 0) {
                int value = Integer.parseInt(editText.getText().toString());
                if(value > 100) {
                    value = 100;
                }
                progressBar.setProgress(value);
            } else {
                Toast.makeText(MainActivity.this, "숫자를 입력해주세요.", Toast.LENGTH_SHORT);
            }
            }
        });

        //버튼 2 : 진행도 다이얼로그
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog = new ProgressDialog(MainActivity.this);
                dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // 빙글빙글 돌아가게끔 설정
                dialog.setMessage("데이터를 확인하는 중입니다...");
                dialog.setCanceledOnTouchOutside(false);    // 화면 터치시 취소되는 기능을 설정하는 메서드
                dialog.show();
            }
        });

        //버튼 3 : 다이얼로그 멈추기
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(dialog != null) {
                    dialog.dismiss();
                }
            }
        });

        //시크바 기능 추가
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            //시크바의 진행도가 변경되면 작동하는 메서드
            //progress : 진행도
            //fromUser : 유저가 직접 변경하면 true, 시스템이 변경했으면 false
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                //editText에는 String 타입만 들어가야 하므로 int 타입인 progress를 String 타입으로 캐스팅한다.
                //방법 ① : "" + int타입
                //editText.setText("" + progress);

                //방법 ② : String.valueOf()
                editText.setText(String.valueOf(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            //값을 변경시키고 손을 뗌
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    //화면이 이미 생성되어 있는 경우에 새 화면을 띄우면 작동
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
    }
}