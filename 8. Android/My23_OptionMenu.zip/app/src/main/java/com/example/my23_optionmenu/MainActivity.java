    package com.example.my23_optionmenu;

    import androidx.annotation.NonNull;
    import androidx.appcompat.app.ActionBar;
    import androidx.appcompat.app.AppCompatActivity;

    import android.os.Bundle;
    import android.view.Menu;
    import android.view.MenuItem;
    import android.widget.Toast;

    public class MainActivity extends AppCompatActivity {
        //액션바 객체 선언
        ActionBar bar;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            bar = getSupportActionBar();
            //액션바 안보이게 설정 방법 ①
    //        bar.hide();

            //액션바 로고 바꾸기
            bar.setLogo(R.drawable.back);
            bar.setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP);

            //로고 클릭할 때 이벤트 발생하게 설정
            bar.setDisplayHomeAsUpEnabled(true);
        }

        //옵션 메뉴 붙이기
        @Override
        public boolean onCreateOptionsMenu(Menu menu) {
            //getMenuInflater() : 프래그먼트 매니저와 비슷한 역할을 함
            getMenuInflater().inflate(R.menu.menu_option, menu);
            return true;
        }

        //옵션 아이콘을 클릭했을 때 이벤트 발생하게끔 설정
        @Override
        public boolean onOptionsItemSelected(@NonNull MenuItem item) {
            int curId = item.getItemId();
            switch (curId) {
                case R.id.menu_refresh :
                    Toast.makeText(this, "새로고침 메뉴 눌림...", Toast.LENGTH_SHORT).show();
                    break;

                case R.id.menu_search :
                    Toast.makeText(this, "검색 메뉴 눌림...", Toast.LENGTH_SHORT).show();
                    break;

                case R.id.menu_settings :
                    Toast.makeText(this, "설정 메뉴 눌림...", Toast.LENGTH_SHORT).show();
                    break;

                //ancroid.R.id.home이 로고의 자리
                case android.R.id.home :
                    Toast.makeText(this, "홈 메뉴 눌림...", Toast.LENGTH_SHORT).show();
                    this.finish();
                    break;
            }
            return true;
        }
    }