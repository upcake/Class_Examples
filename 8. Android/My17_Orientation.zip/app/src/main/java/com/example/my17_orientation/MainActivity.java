package com.example.my17_orientation;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //객체 선언
    String name;
    EditText editText;
    Button button1;

    //onCreate는 저장된 instanceState를 불러다가 화면을 만든다.
    //Bundle : 데이터가 저장된 곳
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        showToast("onCreate() 호출됨");

        //객체 초기화
        editText = findViewById(R.id.editText);
        button1 = findViewById(R.id.button1);

        //버튼 기능 추가
        //누르면 name에 editText의 내용을 가져온다.
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = editText.getText().toString();
                showToast("입력된 값을 변수에 저장하였습니다.");
            }
        });
        if(savedInstanceState != null) {
            name = savedInstanceState.getString("name");
            showToast("값을 복원하였습니다 : " + name);
        }
    }

    //넘겨 받은 문자열을 Toast로 보여주는 메서드
    private void showToast(String str) {
        Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
    }

    //InstanceState를 저장하는 메서드
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("name", name);
    }

    @Override
    protected void onStart() {
        super.onStart();
        showToast("onStart() 호출됨");
    }

    @Override
    protected void onStop() {
        super.onStop();
        showToast("onStop() 호출됨");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        showToast("onDestroy() 호출됨");
    }
}
