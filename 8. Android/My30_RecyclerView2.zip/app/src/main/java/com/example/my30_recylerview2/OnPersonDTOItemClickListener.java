package com.example.my30_recylerview2;

import android.view.View;

public interface OnPersonDTOItemClickListener {
    public void onItemClick(PersonAdapter.ViewHolder holderm, View view, int position);
}
