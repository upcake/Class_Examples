package com.example.my13_service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

//서비스 만들기
//① 패키지 우클릭 - New - Service - Service - 설정 후 Finish
//② AndroidManifest.xml에 서비스 등록 (자동)
//        <service
//            android:name=".MyService"
//            android:enabled="true"
//            android:exported="true"></service>

public class MyService extends Service {
    //logt 자동 완성
    private static final String TAG = "MainMyService";

    public MyService() {
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate: 호출됨");
    }

    //onStartCommand() : 서비스가 실행될 때마다 작동하는 메서드
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "onStartCommand: 호출됨, flags : " + flags + ", startId : " + startId);

        //서비스가 잘못 실행되었다면
        if(intent == null) {
            return Service.START_STICKY;
            //Service.START_STICKY : 서비스를 끄지 않고 다시 시작
        } else {
            processCommand(intent);
        }

        return super.onStartCommand(intent, flags, startId);
    }

    private void processCommand(Intent intent) {
        //putExtra로 보낸 정보를 받는다
        //보낸 name과 받는 name이 같아야 한다
        String command = intent.getStringExtra("command");
        String name = intent.getStringExtra("name");
        Log.d(TAG, "processCommand: " + command + ", name : " + name);

        for (int i = 1; i < 2; i++) {
            try {
                Thread.sleep(1000);
            } catch (Exception e) {
                e.printStackTrace();
            }
            Log.d(TAG, "Waiting: " + i + " seconds...");
        }
    }

    //서비스 종료될때 호출되는 메서드
    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy: 호출됨");
    }

    //onBind는 이제 잘 사용하지 않는다.
    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
