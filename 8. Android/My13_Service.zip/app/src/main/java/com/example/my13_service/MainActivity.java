package com.example.my13_service;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    //객체 선언
    EditText editText;
    Button button1, button2;

    //로그캣 사용 준비
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //객체 초기화
        editText = findViewById(R.id.editText);
        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);

        //기능 추가
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //editText의 텍스트를 가져오고 String 타입으로 캐스팅한다.
                String name = editText.getText().toString();
                Log.d(TAG, "onClick: " + name);

                //컨텍스트 보내고, 무엇을 실행할지 지정
                Intent intent = new Intent(getApplicationContext(), MyService.class);

                //추가적인 정보 전송
                intent.putExtra("command", "show");
                intent.putExtra("name", name);

                //intent 실행
                startService(intent);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MyService.class);

                //서비스 종료
                stopService(intent);
            }
        });
    }
}
