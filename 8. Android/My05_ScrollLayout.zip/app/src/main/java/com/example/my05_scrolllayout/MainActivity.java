package com.example.my05_scrolllayout;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    //변수 선언
    Button btnChange;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //변수 찾기
        btnChange = findViewById(R.id.btnChange);
        imageView = findViewById(R.id.imageView);

        //이벤트 생성
        btnChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageView.setImageResource(R.drawable.image02);
                //setImageResource(R.drawable.이미지이름) : drawable에 있는 이미지를 불러온다.
            }
        });

    }
}
