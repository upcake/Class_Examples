package com.example.my01_helloworld;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Sub1Activity extends AppCompatActivity {

    Button btnMain; // ① 버튼을 선언한다.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub1);

        btnMain = findViewById(R.id.btnMain); // ② 버튼을 찾는다.
        btnMain.setOnClickListener(new View.OnClickListener() { // ③ 버튼의 기능을 지정한다.
            @Override
            public void onClick(View v) {
                finish(); // 서브 창이 닫힌다.
            }
        });
    }
}