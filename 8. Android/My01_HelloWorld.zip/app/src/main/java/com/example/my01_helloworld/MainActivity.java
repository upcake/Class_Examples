package com.example.my01_helloworld;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) { // onCreate() : 메모리에 등록하면서 작동하는 메서드
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // setContentView() : 매개 변수를 화면에 출력하는 메서드
        // R. : resource(res)의 약자
    }
}
