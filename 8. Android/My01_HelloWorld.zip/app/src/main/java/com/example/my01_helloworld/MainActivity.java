package com.example.my01_helloworld;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btnCall; // 전역 변수
    EditText etPhoneNum; // 전역 변수 정의만 할 수 있다.

    @Override
    protected void onCreate(Bundle savedInstanceState) { // onCreate() : 메모리에 등록하면서 작동하는 메서드
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // setContentView() : 매개 변수를 화면에 출력하는 메서드
        // R. : resource(res)의 약자

        etPhoneNum = findViewById(R.id.etPhoneNum);

        btnCall = findViewById(R.id.btnCall); // 지역 변수
        // btnCall이란 id를 가진 객체를 찾아서 btnCall 변수에 입력한다.
        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNum = "tel:" + etPhoneNum.getText().toString();

//                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:010-1234-5678"));
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse(phoneNum));
                startActivity(intent);
            }
        });
    }
    public void btn1Clicked(View view) {
        Toast.makeText(this, "버튼1 클릭!", Toast.LENGTH_SHORT).show();
        // context : 어디에 있는지 환경을 지정
        // this : 현재 참조중인 MainActivity를 지정
        // LENGTH_SHORT : 2 ~ 3초 정도 보여줌
        // LENGTH_LONG : 5초 정도 보여줌
    }

    public void btn2Clicked(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://m.naver.com"));
        startActivity(intent);
        // Intent : 무언가 새 창을 띄울때는 Intent를 사용한다.
    }
}