package com.example.my04_framelayout;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //변수 선언
    Button btnChange;
    ImageView imageView1, imageView2, imageView3;
    int selIdx = 1; // 1, 2, 3번 그림중에 1번을 먼저 보여줄 것이므로 1로 초기화한다.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //변수 찾기
        btnChange = findViewById(R.id.btnChange);
        imageView1 = findViewById(R.id.imageView1);
        imageView2 = findViewById(R.id.imageView2);
        imageView3 = findViewById(R.id.imageView3);

        //이미지 Visibility 설정
        imageView1.setVisibility(View.VISIBLE);
        imageView2.setVisibility(View.GONE);
        imageView3.setVisibility(View.GONE);

        //버튼에 이벤트 삽입
        //버튼을 누르면 보이는 이미지가 바뀌게끔 설정
        btnChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(selIdx == 1) {
                    imageView1.setVisibility(View.VISIBLE);
                    imageView2.setVisibility(View.GONE);
                    imageView3.setVisibility(View.GONE);
                    selIdx = 2;
                    Toast.makeText(MainActivity.this, "1번 선택 됨", Toast.LENGTH_SHORT).show();
                } else if (selIdx == 2) {
                    imageView1.setVisibility(View.GONE);
                    imageView2.setVisibility(View.VISIBLE);
                    imageView3.setVisibility(View.GONE);
                    selIdx = 3;
                    Toast.makeText(MainActivity.this, "2번 선택 됨", Toast.LENGTH_SHORT).show();
                } else if (selIdx == 3) {
                    imageView1.setVisibility(View.GONE);
                    imageView2.setVisibility(View.GONE);
                    imageView3.setVisibility(View.VISIBLE);
                    selIdx = 1;
                    Toast.makeText(MainActivity.this, "3번 선택 됨", Toast.LENGTH_SHORT).show();
                } //if else if
            } //onClick()
        }); //setOnClickListener()
    } //onCreate
} //MainActivity
