package com.example.my26_listview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/*
ListView : 클릭 이벤트를 제공해줘서 편리함.
            메모리 활용이 비효율적

RecyclerView : 클릭 이벤트를 제공해주지않아서 불편함
               메모리 활용이 효율적
*/

public class MainActivity extends AppCompatActivity {
    //객체 선언
    TextView textView;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //객체 초기화
        textView = findViewById(R.id.textView);
        listView = findViewById(R.id.listView);

        //데이터를 담을 리스트와 어댑터 설정
        ArrayList<String> list = new ArrayList<>();
        //어댑터 : 보여지는 View와 View에 올려질 Data를 연결하는 일종의 Bridge
        //android.R.layout.simple.list_item_1 : 단 하나의 String 타입 데이터를 표시하게끔 만들어진 일종의 기본 레이아웃 양식
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);

        //어댑터에 출력된 아이템에 클릭시 기능 추가
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = (String) parent.getItemAtPosition(position);
                textView.setText(selectedItem);
            }
        });

        //리스트에 데이터 추가
        list.add("바나나");
        list.add("딸기");
        list.add("수박");
        list.add("사과");
        list.add("오렌지");
        list.add("망고");
        list.add("키위");
        list.add("포도");
        list.add("멜론");
        list.add("두리안");
    }
}