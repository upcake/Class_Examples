package com.example.my10_intentresult;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    //리퀘스트 코드 설정
    public final int REQUEST_CODE = 1004;

    //변수 선언
    Button btnMain;
    TextView tvMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //변수 초기화
        tvMain = findViewById(R.id.tvMain);
        btnMain = findViewById(R.id.btnMain);

        //기능 추가
        btnMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //데이터 보내기
                //DTO 만들기
                PersonDTO person1 = new PersonDTO("CSS", 3333);

                //인텐트 설정 : ① 컨텍스트 보내기 ② 받는 액티비티.class
                Intent intent = new Intent(MainActivity.this, Sub1Activity.class);
                intent.putExtra("id", "KIM");
                intent.putExtra("pw", 1234);
                intent.putExtra("person1", person1);

                //리퀘스트 설정
                startActivityForResult(intent, REQUEST_CODE);
            }
        });
    }
    //데이터 받기
    //방법 ① : onActivityResult를 만들어서 받기
    //우클릭 - Generate - Override Methods - onActivityResult
    //onAct 자동 완성 - onActivityResult
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode == REQUEST_CODE) {   //requestCode가 1004이고
            if(data != null) {              //data가 null이 아니면
               String key = data.getStringExtra("key");
               tvMain.setText(key);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
