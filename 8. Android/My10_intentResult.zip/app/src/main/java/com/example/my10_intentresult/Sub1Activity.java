package com.example.my10_intentresult;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Sub1Activity extends AppCompatActivity {
    private static final String TAG = "Sub1Activity";

    //변수 선언
    Button btnSub1;
    TextView tvSub1;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub1);

        //변수 초기화
        tvSub1 = findViewById(R.id.tvSub1);
        btnSub1 = findViewById(R.id.btnSub1);

        //데이터 받는 곳
        intent = getIntent();

        if(intent != null) {
            String id = intent.getStringExtra("id");
            int pw = intent.getIntExtra("pw", 0); // int형은 null 값이 넘어올 경우를 대비해서 기본값을 줘야한다.
            PersonDTO person1 = (PersonDTO) intent.getSerializableExtra("person1");
            // Object 타입으로 리턴하기 때문에 DTO 타입으로 캐스팅해준다.

            //Log.d() : Logcat에 출력하는 메서드
            Log.d(TAG, "onCreate id: " + id);
            Log.d(TAG, "onCreate pw: " + pw);
            // String이 쓰여야하므로 pw(int) 단독으로 쓰면 에러가 난다.
            // 문자를 먼저 쓸 경우 자동으로 String으로 캐스팅이 된다.
            // 단독으로 사용해야 할 때는 String.valueOf() 메서드를 사용한다.

            //setText() : textView에 메시지 출력하는 메서드
            tvSub1.setText("받은 값은 : " + id + ", " + pw);

            //append() : 마지막 위치에 문자열을 붙이는 메서드
            tvSub1.append("\nperson1 : " + person1.getId() + ", " + person1.getPw());
        }

        //메인에 데이터 보내기
        btnSub1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent reIntent = new Intent();
                reIntent.putExtra("key", tvSub1.getText().toString() + " ㅋㅋㅋ");
                setResult(RESULT_OK, reIntent);
                finish();
            }
        });
    }
}