package com.example.my10_intentresult;

import java.io.Serializable;

public class PersonDTO implements Serializable {
    String id;
    int pw;

    //생성자
    //우클릭 - Generate - Constructor
    public PersonDTO() { }

    public PersonDTO(String id, int pw) {
        this.id = id;
        this.pw = pw;
    }

    //Getter & Setter
    //우클릭 - Generate - Getter and Setter
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getPw() {
        return pw;
    }

    public void setPw(int pw) {
        this.pw = pw;
    }
}
